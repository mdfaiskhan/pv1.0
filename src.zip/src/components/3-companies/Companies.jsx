import React from 'react'

const Companies = () => {
  return (
    <div>
      Companies
    </div>
  )
}

export default Companies
