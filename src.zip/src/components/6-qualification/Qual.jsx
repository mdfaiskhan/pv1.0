import React from 'react'

const Qual = () => {
  return (
    <div>
      Qualification
    </div>
  )
}

export default Qual
