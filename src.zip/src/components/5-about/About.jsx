import React from 'react'

const About = () => {
  return (
    <div>
      About
      <p>wdeger</p>
      <p>ergeqrgegr</p>
      <p>rewgergr</p>
      <p>ergergreg</p>
      <p>regerre</p>
    </div>
  )
}

export default About
