import React from 'react'

const Project = () => {
  return (
    <div>
      Projects
    </div>
  )
}

export default Project
