import React from "react";
import '../2-main-section/main-style.css'
import image1 from './banner2.jpg'

const Main = () => {
  return (
    <>
      <section className="fMain py-5 w-100 w-31banner">
        {/* <img src={image1} alt="" /> */}
        <div class=" container py-4  ">
          <div className="row align-item-center pt-4 d-flex flex-column">
            <div class="col-md-6 banner-left pe-xl-5">
                    <h4>Hi, I'm Mary Ateer</h4>
                    <h3 class="mb-3 mt-1">Developer<span class="cursor typing">&nbsp;</span></h3>
                    <p class="banner-sub me-md-5">I love to work in UI/UX designing.
                        I always try my best to make good UI with the best UX.
                    </p>
                    <div class="d-flex align-items-center buttons-banner mt-sm-5 mt-4">
                        <a href="about.html" class="btn btn-style me-2">Hire Me</a>
                    </div>
            </div>
            <div className="col-md-6"></div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Main;
