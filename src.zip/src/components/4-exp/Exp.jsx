import React from 'react'

const Exp = () => {
  return (
    <div>
      Experience
    </div>
  )
}

export default Exp
